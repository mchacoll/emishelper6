import { Text as NativeText, StyleSheet, type TextProps } from "react-native";

export function CairoText({ style, ...props }: TextProps) {
  const flattened = StyleSheet.flatten(style);
  const weight = String(flattened?.fontWeight ?? "400");
  const isBold = weight === "bold" || (Number.parseInt(weight, 10) || 0) >= 600;
  return (
    <NativeText
      {...props}
      style={[{ fontFamily: isBold ? "CairoBold" : "CairoRegular" }, style]}
    />
  );
}
