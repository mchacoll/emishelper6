import { EMIS_ORIGIN } from "./emis-webview-types";

export type EmisAutoDiscovery = {
  type: "emis-auto-discovery";
  pageUrl: string;
  authenticated: boolean;
  loginForm: boolean;
  studentListDetected: boolean;
  studentListUrl: string;
  clickedStudentMenu: boolean;
};

export const EMIS_AUTO_DISCOVERY_SCRIPT = String.raw`(function () {
  var officialOrigin = "https://emis.moedu.gov.iq";
  var clean = function (value) { return String(value || "").replace(/\s+/g, " ").trim(); };
  var post = function (data) {
    if (window.ReactNativeWebView) window.ReactNativeWebView.postMessage(JSON.stringify(data));
  };
  var visible = function (node) {
    if (!node || !node.getBoundingClientRect) return false;
    var box = node.getBoundingClientRect();
    var style = window.getComputedStyle(node);
    return box.width > 0 && box.height > 0 && style.display !== "none" && style.visibility !== "hidden";
  };

  function inspect() {
    if (location.origin !== officialOrigin) {
      post({ type: "emis-auto-discovery", pageUrl: location.href, authenticated: false, loginForm: false, studentListDetected: false, studentListUrl: "", clickedStudentMenu: false });
      return;
    }
    var visiblePassword = Array.from(document.querySelectorAll("input[type='password']")).some(visible);
    var loginPath = /\/auth\/login\/?$/i.test(location.pathname);
    var loginForm = visiblePassword || (loginPath && /تسجيل الدخول|sign in|log in/i.test(clean(document.body && document.body.innerText)));
    var pageText = clean(Array.from(document.querySelectorAll("h1,h2,h3,[role='heading']")).map(function (node) { return node.innerText || node.textContent; }).join(" "));
    var headerText = clean(Array.from(document.querySelectorAll("thead th, table th, [role='columnheader']")).map(function (node) { return node.innerText || node.textContent; }).join(" "));
    var rowCount = document.querySelectorAll("table tbody tr, [role='row']").length;
    var routeLooksStudent = /\/(students?|pupils?|learners?)(\/|$|[?#])/i.test(location.pathname);
    var recognizedTable = rowCount > 0 && /(طالب|الطلاب|الطلبة|اسم|student|pupil|learner|رقم)/i.test(headerText);
    var titleLooksStudent = /(قائمة الطلبة|قائمة الطلاب|إدارة الطلاب|students list|student list)/i.test(pageText) && rowCount > 0;
    var studentListDetected = recognizedTable || titleLooksStudent || (routeLooksStudent && rowCount > 0);
    var menuPattern = /(الطلاب|الطلبة|التلاميذ|students?|pupils?)/i;
    var excludedPattern = /(إضافة|اضافة|add new|import|استيراد|حذف|delete|تعديل|edit)/i;
    var nodes = Array.from(document.querySelectorAll("a[href], button, [role='menuitem'], [role='link']")).filter(visible);
    var hasLogout = nodes.some(function (node) {
      var label = clean([node.getAttribute("aria-label"), node.getAttribute("title"), node.innerText, node.textContent].filter(Boolean).join(" "));
      return /(تسجيل الخروج|خروج|log out|logout|sign out)/i.test(label);
    });
    var mayOpenStudentMenu = !loginForm && (!loginPath || hasLogout || studentListDetected);
    var studentListUrl = "";
    var clickedStudentMenu = false;
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      var label = clean([node.getAttribute("aria-label"), node.getAttribute("title"), node.innerText, node.textContent].filter(Boolean).join(" "));
      if (!menuPattern.test(label) || excludedPattern.test(label)) continue;
      var rawHref = node.href || node.getAttribute("data-href") || "";
      if (rawHref) {
        try {
          var parsed = new URL(rawHref, location.href);
          if (parsed.origin === officialOrigin && parsed.protocol === "https:") {
            studentListUrl = parsed.href;
            break;
          }
        } catch (_) {}
      }
      if (mayOpenStudentMenu && node.tagName.toLowerCase() !== "a" && !node.getAttribute("data-emis-auto-clicked")) {
        node.setAttribute("data-emis-auto-clicked", "1");
        node.click();
        clickedStudentMenu = true;
        break;
      }
    }
    var authenticated = !loginForm && (hasLogout || studentListDetected || (!loginPath && (!!studentListUrl || clickedStudentMenu)));
    post({ type: "emis-auto-discovery", pageUrl: location.href, authenticated: authenticated, loginForm: loginForm, studentListDetected: studentListDetected, studentListUrl: studentListUrl, clickedStudentMenu: clickedStudentMenu });
    if (clickedStudentMenu) setTimeout(inspect, 650);
  }

  inspect();
  if (!window.__emisAssistantObserver && window.MutationObserver && document.documentElement) {
    var discoveryTimer;
    var observer = new MutationObserver(function () {
      clearTimeout(discoveryTimer);
      discoveryTimer = setTimeout(inspect, 500);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    window.__emisAssistantObserver = observer;
  }
})(); true;`;

export function parseEmisAutoDiscovery(value: string): EmisAutoDiscovery | null {
  try {
    const parsed = JSON.parse(value) as Partial<EmisAutoDiscovery>;
    if (parsed.type !== "emis-auto-discovery" || typeof parsed.pageUrl !== "string") return null;
    let pageUrl: URL;
    try { pageUrl = new URL(parsed.pageUrl); } catch { return null; }
    if (pageUrl.origin !== EMIS_ORIGIN) return null;
    let studentListUrl = "";
    if (typeof parsed.studentListUrl === "string" && parsed.studentListUrl) {
      try {
        const candidate = new URL(parsed.studentListUrl);
        if (candidate.origin === EMIS_ORIGIN && candidate.protocol === "https:") studentListUrl = candidate.href;
      } catch { studentListUrl = ""; }
    }
    return {
      type: "emis-auto-discovery",
      pageUrl: pageUrl.href,
      authenticated: parsed.authenticated === true,
      loginForm: parsed.loginForm === true,
      studentListDetected: parsed.studentListDetected === true,
      studentListUrl,
      clickedStudentMenu: parsed.clickedStudentMenu === true,
    };
  } catch { return null; }
}
